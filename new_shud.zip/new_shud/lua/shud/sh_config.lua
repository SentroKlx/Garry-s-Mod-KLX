local CFG = {}
Shud.HUD.Config = CFG

// NE PAS TOUCHER SI VOUS NE CONNAISSEZ PAS CECI PEUT CREER UNE ERREUR EN CAS DE MODIFICATION 


CFG["test"] = false

// Vous pouvez changer le préfixe selon votre serveur : € / $
CFG["Money"] = " $"

// Changez la couleur image argent
CFG["ColorIconMoney"] = Color(14, 255, 6, 255)

// Changez la couleur image burger
CFG["ColorIconBurger"] = Color(255, 120, 6, 255)

// Changez la couleur image armure
CFG["ColorIconArmor"] = Color(0, 94, 255, 255)

// Changez la couleur image coeur
CFG["ColorIconHealth"] = Color(255, 0, 0, 255)

// Changez la couleur de la barre de vie 
CFG["ColorHealth"] = Color(255, 0, 0, 255)

// Changez la couleur du fond de la barre de vie
CFG["ColorHealthBackground"] = Color(165, 0, 0, 255)

// Changez la couleur de la barre armure
CFG["ColorArmor"] = Color(0, 94, 255, 255)

// Changez la couleur du fond de la barre armure
CFG["ColorArmorBackground"] = Color(2, 38, 100, 255)

// Changez la couleur de la barre de faim
CFG["ColorFood"] = Color(255, 120, 6, 255)

// Changez la couleur du fond de la barre de Faim
CFG["ColorFoodBackground"] = Color(181, 84, 0, 255)

// Changez la couleur de la barre argent 
CFG["ColorMoney"] = Color(14, 255, 6, 255)